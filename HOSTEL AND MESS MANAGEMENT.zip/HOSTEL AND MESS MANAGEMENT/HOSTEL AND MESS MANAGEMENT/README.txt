THIS PROJECT IS MADE IN NETBEANS IDE AND BUILD IN WINDOWS OPERAITING SYSTEM.


FOR RUNNING THE PROJECT.

1.Copy the "dbmsproject" in your PC Netbeansproject folder where the netbeans usually stores its project.
	eg: "C:\Users\Win8.1\Documents\NetBeansProjects"
2.Then open netbeans IDE then import this project in your netbeans IDE.
3.Open MYSQL then create a database named "hostel" then paste all the tables from the database folder in this to your hostel database in MYSQL workbench.
4.Open the project and run the Main.java file.



IF ERRORS ARE THERE REGARDING MYSQL:

You must change the root password of your mysql to "open"..  or you can replace "open" to [your password here] of you MYSQL.
In the code in making connection you have to set the MYSQL passord so you must change that passqord in the program to your password.
There is a image showing wher to change in the code.
you have to change every occurance of that.