/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class SearchController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private JFXButton x;

    @FXML
    private StackPane workerstackpane;

    @FXML
    private TextField wtext2;

    @FXML
    private TextField wtext1;

    @FXML
    private TextField wtext3;

    @FXML
    private JFXButton wgo;

    @FXML
    private JFXButton x2;

    @FXML
    private StackPane roomstackpane;
    
    @FXML
    private StackPane studentstackpane;

    @FXML
    private JFXButton x3;
    @FXML
    private JFXButton home;
    @FXML
    private JFXButton stubut;
    @FXML
    private JFXButton worbut;
    @FXML
    private JFXButton roombut;
    @FXML
    private TextField stext1;
    @FXML
    private TextField stext2;
    @FXML
    private TextField stext3;
    @FXML
    private JFXButton go;
   
    
    @FXML
    private TableView<searchstudentDetail> table1;
    @FXML
    private TableColumn<searchstudentDetail, String> name1;
    @FXML
    private TableColumn<searchstudentDetail, String> roll1;
    @FXML
    private TableColumn<searchstudentDetail, String> username1;
    @FXML
    private TableColumn<searchstudentDetail, String> fname1;
    @FXML
    private TableColumn<searchstudentDetail, String> mname1;
    @FXML
    private TableColumn<searchstudentDetail, String> dob1;
    @FXML
    private TableColumn<searchstudentDetail, String> adress1;
    @FXML
    private TableColumn<searchstudentDetail, String> cont1;
    @FXML
    private TableColumn<searchstudentDetail, String> doj1;
    @FXML
    private TableView<searchworkerDetail> table2;
    @FXML
    private TableColumn<searchworkerDetail,String> name2;
    @FXML
    private TableColumn<searchworkerDetail, String> address2;
    @FXML
    private TableColumn<searchworkerDetail, String> cont2;
    @FXML
    private TableColumn<searchworkerDetail, String> doj2;
    @FXML
    private TableColumn<searchworkerDetail, String> work;
    @FXML
    private TableView<searchroomDetail> table3;
    @FXML
    private TableColumn<searchroomDetail, String> S3;
    @FXML
    private TableColumn<searchroomDetail, String> room3;
    @FXML
    private TableColumn<searchroomDetail, String> occ3;
    @FXML
    private TableColumn<searchroomDetail, String> rno;
    @FXML
    private TableColumn<searchroomDetail, String> doa3;
    @FXML
    private TableColumn<searchroomDetail, String> cont3;
    private ObservableList<searchstudentDetail>data;
    private DbConnection dc;
    private ObservableList<searchworkerDetail>data2;
    private DbConnection dc2;
    private ObservableList<searchroomDetail>data3;
    private DbConnection dc3;
    @FXML
    private TextField roomtext2;
    @FXML
    private TextField roomtext1;
    @FXML
    void closex(ActionEvent event) {
        studentstackpane.setVisible(false);
    }
    
    @FXML
    void closex2(ActionEvent event) {
        workerstackpane.setVisible(false);
    }
    @FXML
    void closex3(ActionEvent event) {
        roomstackpane.setVisible(false);
    }
    @FXML
    void back(ActionEvent event) {
          try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("option.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    @FXML
    void gosearch(ActionEvent event) {
         String s=stext1.getText();
         String s2=stext2.getText();
         String s3=stext3.getText();
         try{
            Connection conn=  dc.Connect();
            data = FXCollections.observableArrayList();
        
        ResultSet rs=conn.createStatement().executeQuery("SELECT * FROM addstudent");
        while(rs.next()){
          if(s.equals(rs.getString("name")) || s2.equals(rs.getString("roll_no")) || s3.equals(rs.getString("dob"))) {      
            data.add(new searchstudentDetail(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)));
          }
        }
        
    } catch(SQLException ex){
        System.out.println("Error"+ex);
    }
    
    name1.setCellValueFactory(new PropertyValueFactory<>("name"));
    roll1.setCellValueFactory(new PropertyValueFactory<>("roll_no"));
    username1.setCellValueFactory(new PropertyValueFactory<>("username"));
    fname1.setCellValueFactory(new PropertyValueFactory<>("father_name"));
    mname1.setCellValueFactory(new PropertyValueFactory<>("mother_name"));
    dob1.setCellValueFactory(new PropertyValueFactory<>("dob"));
    adress1.setCellValueFactory(new PropertyValueFactory<>("address"));
    cont1.setCellValueFactory(new PropertyValueFactory<>("phone"));
    doj1.setCellValueFactory(new PropertyValueFactory<>("doj"));
    table1.setItems(null);
       
    table1.setItems(data);
    
    }

    @FXML
    void roomser(ActionEvent event) {
        roomstackpane.setVisible(true);
    }

    @FXML
    void stuser(ActionEvent event) {
        studentstackpane.setVisible(true);
    }

    @FXML
    void wgosearch(ActionEvent event) {
        String s=wtext1.getText();
        String s2=wtext2.getText();
        String s3=wtext3.getText();
        try{
            Connection conn=  dc2.Connect();
            data2 = FXCollections.observableArrayList();
        
        ResultSet rs=conn.createStatement().executeQuery("SELECT * FROM worker_info");
        while(rs.next()){
                      if(s.equals(rs.getString("name")) || s2.equals(rs.getString("work")) || s3.equals(rs.getString("doj"))) {      
                        data2.add(new searchworkerDetail(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
                      }
        }
        
    } catch(SQLException ex){
        System.out.println("Error"+ex);
    }
    
    name2.setCellValueFactory(new PropertyValueFactory<>("name"));
    address2.setCellValueFactory(new PropertyValueFactory<>("address"));
    cont2.setCellValueFactory(new PropertyValueFactory<>("contact"));
    doj2.setCellValueFactory(new PropertyValueFactory<>("date"));
    work.setCellValueFactory(new PropertyValueFactory<>("work"));
    table2.setItems(null);
       
    table2.setItems(data2);
    }

    @FXML
    void worser(ActionEvent event) {
        workerstackpane.setVisible(true);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dc=new DbConnection();  
        dc2=new DbConnection(); 
        dc3=new DbConnection(); 
    }    


    @FXML
    private void roomgo(ActionEvent event) throws SQLException {
         String s=roomtext1.getText();
         String s2=roomtext2.getText();
         try {
            Connection conn = dc3.Connect();
            data3 = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM rooms");
            while (rs.next()) {
                //get string from db,whichever way
                 if(s.equals(rs.getString("room_no")) || s2.equals(rs.getString("occupied_by"))) {      
                    data3.add(new searchroomDetail(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
                 }
            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }
        S3.setCellValueFactory(new PropertyValueFactory<>("serial_no"));
        room3.setCellValueFactory(new PropertyValueFactory<>("room_no"));
        occ3.setCellValueFactory(new PropertyValueFactory<>("occupied_by"));
        rno.setCellValueFactory(new PropertyValueFactory<>("roll_no"));
        doa3.setCellValueFactory(new PropertyValueFactory<>("date_of_allotment"));
        cont3.setCellValueFactory(new PropertyValueFactory<>("contact"));
        table3.setItems(null);
        table3.setItems(data3);
    }

    
}
