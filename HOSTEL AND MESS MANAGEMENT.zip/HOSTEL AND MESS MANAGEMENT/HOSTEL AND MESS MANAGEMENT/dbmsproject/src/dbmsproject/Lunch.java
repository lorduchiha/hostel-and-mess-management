/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author MAC
 */
public class Lunch {

    private final StringProperty day;
    private final StringProperty items;

    public Lunch(String day, String items) {
        this.day = new SimpleStringProperty(day);
        this.items = new SimpleStringProperty(items);

    }

    public String getDay() {
        return day.get();
    }

    public String getItems() {
        return items.get();
    }
    public void setDay(String value) {
        day.set(value);
    }
    public void setItems(String value) {
        items.set(value);
    }
    public StringProperty dayProperty() {
        return day;
    }
    public StringProperty itemsProperty() {
        return items;
    }
}
