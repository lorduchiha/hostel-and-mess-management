/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author niketan verma1
 */
public class ListOfInmatesDetails {
    
    private final StringProperty name;
    private final StringProperty rollno;
    private final StringProperty roomno;
    private final StringProperty contact;
    private final StringProperty date;

    ListOfInmatesDetails( String name, String rollno, String roomno, String contact, String date) {
        
        this.name = new SimpleStringProperty(name);
        this.rollno = new SimpleStringProperty(rollno);
        this.roomno = new SimpleStringProperty(roomno);
        this.contact = new SimpleStringProperty(contact);
        this.date = new SimpleStringProperty(date);
    }
    

    public String getName() {
        return name.get();
    }

    public String getRollno() {
        return rollno.get();
    }
    public String getRoomno() {
        return roomno.get();
    }
   
    public String getContact() {
        return contact.get();
    }
     public String getDate() {
        return date.get();
    }
    

    public void setName(String value) {
        name.set(value);
    }

    public void setRollno(String value) {
        rollno.set(value);
    }
    
    public void setRoomno(String value) {
        roomno.set(value);
    }
    
     public void setContact(String value) {
        contact.set(value);
    }
      public void setDate(String value) {
        date.set(value);
    }
      

    public StringProperty nameProperty() {
        return name;
    }

    public StringProperty rollnoProperty() {
        return rollno;
    }
    
    public StringProperty roomnoProperty() {
        return roomno;
    }
     
      public StringProperty contactProperty() {
        return contact;
    }
      public StringProperty dateProperty() {
        return date;
    }
}
