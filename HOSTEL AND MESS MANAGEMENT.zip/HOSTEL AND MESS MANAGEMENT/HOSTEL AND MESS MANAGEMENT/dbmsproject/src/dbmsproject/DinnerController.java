/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author MAC
 */
public class DinnerController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TableView<Dinner> tableUser;
    @FXML
    private TableColumn<Dinner, String> columnDay;
    @FXML
    private TableColumn<Dinner, String> columnItems;
    @FXML
    private Button btnView;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private Label label;
    @FXML
    private JFXButton b1;
    @FXML
    private AnchorPane andhorpane;

    /**
     * Initializes the controller class.
     */
    private ObservableList<Dinner> data;
    private DbConnection dc;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        dc = new DbConnection();
    }

    @FXML
    private void ViewDetails(ActionEvent event) {
        try {
            Connection conn = dc.Connect();
            data = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM dinner");
            while (rs.next()) {
                //get string from db,whichever way 
                data.add(new Dinner(rs.getString(1), rs.getString(2)));
            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        //Set cell value factory to tableview.
        //NB.PropertyValue Factory must be the same with the one set in model class.
        columnDay.setCellValueFactory(new PropertyValueFactory<>("day"));
        columnItems.setCellValueFactory(new PropertyValueFactory<>("items"));
        tableUser.setItems(null);
        tableUser.setItems(data);
    }

    @FXML
    private void UpdateDetails(ActionEvent event) {
        try {
            AnchorPane pane1 = FXMLLoader.load(getClass().getResource("UpdateDinner.fxml"));
            andhorpane.getChildren().setAll(pane1);

            FadeTransition fade2 = new FadeTransition(Duration.seconds(2), pane1);
            fade2.setFromValue(0);
            fade2.setToValue(1);
            fade2.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void DeleteDetails(ActionEvent event) {
        try {
            AnchorPane pane3  = FXMLLoader.load(getClass().getResource("DeleteDinner.fxml"));
            andhorpane.getChildren().setAll(pane3);

            FadeTransition fade3 = new FadeTransition(Duration.seconds(2), pane3);
            fade3.setFromValue(0);
            fade3.setToValue(1);
            fade3.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void back(ActionEvent event) {
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("Menu.fxml"));
            andhorpane.getChildren().setAll(pane);

            FadeTransition fade1 = new FadeTransition(Duration.seconds(2), pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }  
    
}
