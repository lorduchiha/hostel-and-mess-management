/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author MAC
 */
public class UpdateLunchController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane andhorpane;

    @FXML
    private Label b1;

    @FXML
    private Label b2;

    @FXML
    private Button btnback1;

    @FXML
    private JFXTextField text2;

    @FXML
    private JFXTextField text1;

    @FXML
    private JFXButton btnUpdate1;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void back1(ActionEvent event) {
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("Lunch.fxml"));
            andhorpane.getChildren().setAll(pane);

            FadeTransition fade1 = new FadeTransition(Duration.seconds(2), pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void itemUpdate1(ActionEvent event) {
        String day = text1.getText();
        String items = text2.getText();
        String old = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Statement x = null;
        text1.setText(null);
        text2.setText(null);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel", "root", "open");
            pstmt = (PreparedStatement) conn.prepareStatement("select * from lunch where day = ?");
            pstmt.setString(1, day);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                old = (rs.getString("items"));
            }
            old = old +"," + items;
            pstmt = (PreparedStatement) conn.prepareStatement("update lunch set items  = ? where day = ?");

            pstmt.setString(1, old);
            pstmt.setString(2, day);
            int i = pstmt.executeUpdate();
            if (i > 0) {
                JOptionPane.showMessageDialog(null, "Item is Saved");
            } else {
                JOptionPane.showMessageDialog(null, "Item is not Saved");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

}
