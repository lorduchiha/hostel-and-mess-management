/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.beans.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class RegisterController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private JFXTextField text1;

    @FXML
    private JFXTextField text2;

    @FXML
    private JFXPasswordField text4;

    @FXML
    private JFXTextField text3;

    @FXML
    private JFXButton signup;

    @FXML
    private JFXButton back;

    @FXML
    void home(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("option.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    void sign(ActionEvent event) {
        String name = text1.getText();
        String username = text2.getText();
        String rollno = text3.getText();
        String pass = text4.getText();
        Connection conn  = null;
        PreparedStatement pstmt = null;
        ResultSet rs  = null;
        Statement x = null;
        text1.setText(null);
        text2.setText(null);
        text3.setText(null);
        text4.setText(null);
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
            pstmt =  (PreparedStatement) conn.prepareStatement("insert into signupstudent values(?,?,?,?,?)");
            pstmt.setString(1 ,name);
            pstmt.setString(2,username);
            pstmt.setString(3,rollno);
            pstmt.setString(4,pass);
            pstmt.setString(5,"Unregisterd");
            
            
   
            int i = pstmt.executeUpdate();
            if(i>0)
            JOptionPane.showMessageDialog(null, "Data is Saved");
            else
            JOptionPane.showMessageDialog(null, "Data is not Saved");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);

        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
