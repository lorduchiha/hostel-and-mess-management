/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author MAC
 */
public class RoomsDetails {

    private final StringProperty roll_no;
    private final StringProperty occupied_by;
    private final StringProperty contact;
    private final StringProperty serial_no;
    private final StringProperty room_no;
    private final StringProperty date_of_allotment;

    //Default constructor
    public RoomsDetails(String serial_no, String room_no, String occupied_by, String roll_no, String date_of_allotment, String contact) {
        this.serial_no = new SimpleStringProperty(serial_no);
        this.room_no = new SimpleStringProperty(room_no);
        this.occupied_by = new SimpleStringProperty(occupied_by);
        this.roll_no = new SimpleStringProperty(roll_no);
        this.date_of_allotment = new SimpleStringProperty(date_of_allotment);
        this.contact = new SimpleStringProperty(contact);

    }

    //Getters
    public String getSerial_no() {
        return serial_no.get();
    }

    public String getRoll_no() {
        return roll_no.get();
    }

    public String getOccupied_by() {
        return occupied_by.get();
    }

    public String getContact() {
        return contact.get();
    }

    public String getRoom_no() {
        return room_no.get();
    }

    public String getDate_of_allotment() {
        return date_of_allotment.get();
    }

    //Setters
    public void setSerial_no(String value) {
        serial_no.set(value);
    }

    public void setRoll_no(String value) {
        roll_no.set(value);
    }

    public void setOccupied_by(String value) {
        occupied_by.set(value);
    }

    public void setContact(String value) {
        contact.set(value);
    }

    public void setRoom_no(String value) {
        room_no.set(value);
    }

    public void setDate_of_allotment(String value) {
        date_of_allotment.set(value);
    }

    //Property values
    public StringProperty serial_noProperty() {
        return serial_no;
    }

    public StringProperty roll_noProperty() {
        return roll_no;
    }

    public StringProperty occupied_byProperty() {
        return occupied_by;
    }

    public StringProperty contactProperty() {
        return contact;
    }

    public StringProperty room_noProperty() {
        return room_no;
    }

    public StringProperty date_of_allotmentProperty() {
        return date_of_allotment;
    }
}
