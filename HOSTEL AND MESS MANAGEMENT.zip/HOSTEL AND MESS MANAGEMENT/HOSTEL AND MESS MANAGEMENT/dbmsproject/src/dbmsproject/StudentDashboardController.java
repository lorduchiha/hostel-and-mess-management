/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class StudentDashboardController implements Initializable {

    
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private JFXButton b1;

    @FXML
    private JFXButton b2;
    @FXML
    private TextField username;

    @FXML
    private JFXButton b3;
    static String str;
    @FXML
    private JFXButton menubut;
    @FXML
    void back(ActionEvent event) {
         try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("option.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    void bill(ActionEvent event) {
         try {
                GenerateBillController.s = username.getText();
                AnchorPane pane = FXMLLoader.load(getClass().getResource("GenerateBill.fxml"));
                anchorpane.getChildren().setAll(pane);

               FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
               fade1.setFromValue(0);
               fade1.setToValue(1);
               fade1.play();
               } catch (IOException ex) {
               Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
               }
    }

    @FXML
    void info(ActionEvent event) {
         try {
             InformationController.str1 = str;
             AnchorPane pane = FXMLLoader.load(getClass().getResource("Information.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        username.setText(str);
    }    

    @FXML
    private void menubutton(ActionEvent event) {
             try {
             InformationController.str1 = str;
             AnchorPane pane = FXMLLoader.load(getClass().getResource("FXML.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
}
