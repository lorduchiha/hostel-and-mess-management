/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class AdminsigninController implements Initializable {

    @FXML
    private JFXTextField usertext;
    @FXML
    private JFXPasswordField passtext;
    @FXML
    private JFXButton log;
    @FXML
    private JFXButton home;
    @FXML
    private AnchorPane amchorpane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void login(ActionEvent event) {
        String s;
        String p;
        s=usertext.getText();
        p=passtext.getText();
        //System.out.println(s+" "+p);
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
            pstmt=(PreparedStatement) conn.prepareStatement("select * from admin");
            rs=pstmt.executeQuery();
            int flag=0;
            while(rs.next()) {
                if(s.equals(rs.getString("username")) && p.equals(rs.getString("password"))) {      
                    try {
                        flag = 1;
                        AnchorPane pane = FXMLLoader.load(getClass().getResource("adminDashboard.fxml"));
                        amchorpane.getChildren().setAll(pane);

                       FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
                       fade1.setFromValue(0);
                       fade1.setToValue(1);
                       fade1.play();
                       } catch (IOException ex) {
                       Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
                       }
                           }
            }
            if(flag==0) {
                JOptionPane.showMessageDialog(null, "Wrong Username or Password", "Login Failed", JOptionPane.ERROR_MESSAGE);                
                
            }
        }
		catch(Exception e) {
             System.out.println(e);
        }
    }

    @FXML
    private void back(ActionEvent event) {
            try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("option.fxml"));
             amchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
}
