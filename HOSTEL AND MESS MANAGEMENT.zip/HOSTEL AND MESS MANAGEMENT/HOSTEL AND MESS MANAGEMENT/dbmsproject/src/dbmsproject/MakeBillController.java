/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.mysql.jdbc.PreparedStatement;
import static dbmsproject.InformationController.str1;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class MakeBillController implements Initializable {

   
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private TextField text1;
    @FXML
    private TextField ammount;


    @FXML
    private TextField text2;

    @FXML
    private TextField text3;

    @FXML
    private JFXButton b2;

    @FXML
    private JFXButton b1;

    @FXML
    void home(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("adminDashboard.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    void makebill(ActionEvent event) 
    {
        String rollno = text2.getText();
        String amo = ammount.getText();
        String name = text1.getText();
        text1.setText(null);
        text2.setText(null);
        text3.setText(null);
        ammount.setText(null);
        Connection conn  = null;
        PreparedStatement pstmt = null;
        ResultSet rs  = null;
        Statement x = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
            pstmt =  (PreparedStatement) conn.prepareStatement("insert into generatebill values(?,?,?)");
            pstmt.setString(1,rollno);
            pstmt.setString(2 ,amo);
            pstmt.setString(3,name);
            int i = pstmt.executeUpdate();
            if(i>0)
            JOptionPane.showMessageDialog(null, "Bill Has  Generated Successfully");
            else
            JOptionPane.showMessageDialog(null, "Data is not Saved");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);

        }

    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
