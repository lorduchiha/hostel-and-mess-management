/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class InformationController implements Initializable {

    /**
     * Initializes the controller class.
     */
    static String str1 ;
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private JFXButton b1;

    @FXML
    private TextField text1;

    @FXML
    private TextField text2;

    @FXML
    private TextField text3;

    @FXML
    private TextField text4;

    @FXML
    private TextField text5;

    @FXML
    private TextField text6;

    @FXML
    private TextField text7;

    @FXML
    private TextField text8;

    @FXML
    private TextField text9;

    @FXML
    void close(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("StudentDashboard.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
            pstmt=(PreparedStatement) conn.prepareStatement("select * from addstudent where username = ?");
            pstmt.setString(1,str1 );
            rs=pstmt.executeQuery();
            while(rs.next())
            {    
                text1.setText(rs.getString("name"));
                text2.setText(rs.getString("father_name"));
                text3.setText(rs.getString("mother_name"));
                text4.setText(rs.getString("roll_no"));
                //text5.setText(rs.getString("roomno"));
                text6.setText(rs.getString("address"));
                text7.setText(rs.getString("phone"));
            }    
        }
        catch(Exception e) {
             System.out.println(e);
        }
   
    }    
    
}
