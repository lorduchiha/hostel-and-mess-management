/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class OptionController implements Initializable {
    
    @FXML
    private AnchorPane anchorpane;
    
    @FXML
    private JFXButton b6;
    
    @FXML
    private JFXButton b7;
    
    @FXML
    private JFXButton admin;

    @FXML
    private JFXButton student;

    @FXML
    private JFXButton add;
     
    @FXML
    void exit(ActionEvent event) {
        System.exit(1);
    }
    @FXML
    private JFXButton find;

    @FXML
    void adding(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("Register.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    void adminlogin(ActionEvent event) {
         try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("adminsignin.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    void studentlogin(ActionEvent event) {
         try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("signin.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    @FXML
    void developers(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("Developers.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    @FXML
    void search(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("Search.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        Polyline path = new Polyline();
//        path.getPoints().addAll(new Double[]{
//            0.0,0.0,
//            1400.0,0.0});
//        PathTransition transition = new PathTransition();
//        transition.setNode(c1);
//        transition.setDuration(Duration.seconds(1));
//        transition.setCycleCount(Animation.INDEFINITE);
//        transition.setPath(path);
//        transition.setAutoReverse(true);
//        transition.play();
        
    }    
    
}
