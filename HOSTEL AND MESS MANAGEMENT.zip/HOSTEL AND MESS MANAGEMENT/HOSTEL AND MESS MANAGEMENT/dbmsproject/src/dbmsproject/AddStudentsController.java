/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import static java.awt.SystemColor.text;
import java.beans.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class AddStudentsController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private TextField text1;

    @FXML
    private TextField text2;

    @FXML
    private TextField text3;

    @FXML
    private TextField text4;

    @FXML
    private TextField text5;

    @FXML
    private TextField text6;

    @FXML
    private TextField text7;

    @FXML
    private JFXButton b1;
    
    @FXML
    private TextField text11;

    @FXML
    private TextField text111;

    @FXML
    private JFXButton home;
    @FXML
    private JFXButton but2;
    @FXML
    private StackPane stackpane;
    @FXML
    private TableView<AddStudentsDetail> table;
    @FXML
    private TableColumn<AddStudentsDetail, String> columnname;
    @FXML
    private TableColumn<AddStudentsDetail, String> columnrollno;
    @FXML
    private TableColumn<AddStudentsDetail, String> columnusername;
    @FXML
    private TableColumn<AddStudentsDetail, String> columnregstatus;
    @FXML
    private TableColumn<AddStudentsDetail, String> columnpassword;
    @FXML
    private TextField rolltext;
    @FXML
    private JFXButton butclose;
    @FXML
    private JFXButton loadbut;
    
    private ObservableList<AddStudentsDetail>data;
    private DbConnection dc;
    
    
    @FXML
    void back(ActionEvent event) {
    
           try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("adminDashboard.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @FXML
    void add(ActionEvent event) {
        
    String NAME=text1.getText();
    String ROLL_NO= text11.getText();
    String USERNAME= text111.getText();
    String FATHER_NAME= text2.getText();
    String MOTHER_NAME= text3.getText();
    String DOB= text4.getText();
    String ADDRESS= text5.getText();
    String PHONE_NO= text6.getText();
    String DATE_OF_JOINING= text7.getText();
    Connection conn=null;
    PreparedStatement pstmt=null;
    ResultSet rs=null;
    Statement x=null;
    text1.setText(null);
    text11.setText(null);
    text111.setText(null);
    text2.setText(null);
    text3.setText(null);
    text4.setText(null);
    text5.setText(null);
    text6.setText(null);
    text7.setText(null);
    try{
        Class.forName("com.mysql.jdbc.Driver");
        conn=DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
        pstmt=(PreparedStatement) conn.prepareStatement("insert into addstudent values(?,?,?,?,?,?,?,?,?)");
        pstmt.setString(1,NAME);
        pstmt.setString(2,ROLL_NO);
        pstmt.setString(3,USERNAME);
        pstmt.setString(4,FATHER_NAME);
        pstmt.setString(5,MOTHER_NAME);
        pstmt.setString(6,DOB);
        pstmt.setString(7,ADDRESS);
        pstmt.setString(8,PHONE_NO);
        pstmt.setString(9,DATE_OF_JOINING);
        int i= pstmt.executeUpdate();
        pstmt=(PreparedStatement) conn.prepareStatement("update signupstudent set status = ? where rollno = ?");
        pstmt.setString(1,"Registered");
        pstmt.setString(2,ROLL_NO);
        int j= pstmt.executeUpdate();
        if(i>0)
            JOptionPane.showMessageDialog(null,"Data is saved");
        else
            JOptionPane.showMessageDialog(null,"Data is not saved");
        if(j>0)
            JOptionPane.showMessageDialog(null,"Data is saved");
        else
            JOptionPane.showMessageDialog(null,"Data is not saved");
    }   
    catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
    
    }
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        dc=new DbConnection();
    }    

    @FXML
    private void list(ActionEvent event) {
        stackpane.setVisible(true);
    }

    @FXML
    private void close(ActionEvent event) {
        stackpane.setVisible(false);
    }   

    @FXML
    private void loadvalues(ActionEvent event) {
        String temp=null;
        temp = rolltext.getText();
        
        
       try{
            Connection conn=  dc.Connect();
            data = FXCollections.observableArrayList();
        
        ResultSet rs=conn.createStatement().executeQuery("SELECT * FROM signupstudent ");
        while(rs.next()){
           //if(temp.equals(rs.getString("rollno"))){
                 data.add(new AddStudentsDetail(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
           //}
        }
        
    } catch(SQLException ex){
        System.out.println("Error"+ex);
    }
    
    columnname.setCellValueFactory(new PropertyValueFactory<>("name"));
    columnusername.setCellValueFactory(new PropertyValueFactory<>("username"));
    columnrollno.setCellValueFactory(new PropertyValueFactory<>("rollno"));
    columnregstatus.setCellValueFactory(new PropertyValueFactory<>("status"));
   

    table.setItems(null);
       
    table.setItems(data);
    
    }
    
}
