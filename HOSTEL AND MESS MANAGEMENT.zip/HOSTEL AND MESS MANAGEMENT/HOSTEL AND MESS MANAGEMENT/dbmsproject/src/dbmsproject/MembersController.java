/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class MembersController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private JFXButton b1;
    @FXML
    private TableView<MembersDetails> tableUser;
    
    @FXML
    private TableColumn<MembersDetails, String> columnname;
    @FXML
    private TableColumn<MembersDetails, String> columnrollno;
    @FXML
    private TableColumn<MembersDetails, String> columnroomno;
    @FXML
    private TableColumn<MembersDetails, String> columnaddress;
    @FXML
    private TableColumn<MembersDetails, String> columncontact;
    @FXML
    private TableColumn<MembersDetails, String> columndate;
    @FXML
    private TableColumn<MembersDetails, String> columntype;

     
    @FXML
    private Button btnLoad;
    private ObservableList<MembersDetails>data;
    private DbConnection dc;
    
    @FXML
    void back(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("MessManagement.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        dc=new DbConnection();
    }    

    @FXML
    private void LoadDataFromDatabase(ActionEvent event) {
        try{
            Connection conn=  dc.Connect();
            data = FXCollections.observableArrayList();
        
        ResultSet rs=conn.createStatement().executeQuery("SELECT * FROM memberinfo");
        while(rs.next()){
          data.add(new MembersDetails(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)));
        }
        
    } catch(SQLException ex){
        System.out.println("Error"+ex);
    }
   
    columnname.setCellValueFactory(new PropertyValueFactory<>("name"));
    columnrollno.setCellValueFactory(new PropertyValueFactory<>("rollno"));
    columnroomno.setCellValueFactory(new PropertyValueFactory<>("roomno"));
    columnaddress.setCellValueFactory(new PropertyValueFactory<>("address"));
    columncontact.setCellValueFactory(new PropertyValueFactory<>("contact"));
    columndate.setCellValueFactory(new PropertyValueFactory<>("date"));
    columntype.setCellValueFactory(new PropertyValueFactory<>("type"));
    tableUser.setItems(null);
       
    tableUser.setItems(data);
    

    }
    
}
