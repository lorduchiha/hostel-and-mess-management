/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class FXMLController implements Initializable {

    @FXML
    private JFXButton breakbut;
    @FXML
    private JFXButton lunchbut;
    @FXML
    private JFXButton dinnerbut;
    @FXML
    private StackPane stackpane;
    @FXML
    private TableView<Lunch> table2;
    @FXML
    private TableColumn<Lunch, String> day2;
    @FXML
    private TableColumn<Lunch, String> item2;
    @FXML
    private JFXButton lb1;
    @FXML
    private StackPane stackpane2;
    @FXML
    private TableView<BreakDetails> table1;
    @FXML
    private TableColumn<BreakDetails, String> day1;
    @FXML
    private TableColumn<BreakDetails, String> item1;
    @FXML
    private JFXButton lb2;
    @FXML
    private StackPane stackpane3;
    @FXML
    private TableView<Dinner> table3;
    @FXML
    private TableColumn<Dinner, String> day3;
    @FXML
    private TableColumn<Dinner, String> item3;
    @FXML
    private JFXButton lb3;
    private ObservableList<BreakDetails> data;
    private DbConnection dc;
    private ObservableList<Lunch> data2;
    private DbConnection dc2;
    private ObservableList<Dinner> data3;
     private DbConnection dc3;
    @FXML
    private JFXButton lb11;
    @FXML
    private JFXButton lb21;
    @FXML
    private JFXButton lb31;
    @FXML
    private JFXButton exit;
    @FXML
    private AnchorPane anchorpane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dc = new DbConnection();
        dc2 = new DbConnection();
        dc3 = new DbConnection();

    }    

    @FXML
    private void breakfast(ActionEvent event) {
        stackpane.setVisible(true);
    }

    @FXML
    private void lunch(ActionEvent event) {
        stackpane2.setVisible(true);
    }

    @FXML
    private void dinner(ActionEvent event) {
        stackpane3.setVisible(true);
    }

    @FXML
    private void loadvalue(ActionEvent event) {
       try {
            Connection conn = dc.Connect();
            data = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM breakfast");
            while (rs.next()) {
                //get string from db,whichever way 
                data.add(new BreakDetails(rs.getString(1), rs.getString(2)));
            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        //Set cell value factory to tableview.
        //NB.PropertyValue Factory must be the same with the one set in model class.
        day1.setCellValueFactory(new PropertyValueFactory<>("day"));
        item1.setCellValueFactory(new PropertyValueFactory<>("items"));
        table1.setItems(null);
        table1.setItems(data);
    }

    @FXML
    private void loadvalue2(ActionEvent event) {
         try {
            Connection conn = dc2.Connect();
            data2 = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM lunch");
            while (rs.next()) {
                //get string from db,whichever way 
                data2.add(new Lunch(rs.getString(1), rs.getString(2)));
            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        //Set cell value factory to tableview.
        //NB.PropertyValue Factory must be the same with the one set in model class.
        day2.setCellValueFactory(new PropertyValueFactory<>("day"));
        item2.setCellValueFactory(new PropertyValueFactory<>("items"));
        table2.setItems(null);
        table2.setItems(data2);
    }

    @FXML
    private void loadvalue3(ActionEvent event) {
        try {
            Connection conn = dc3.Connect();
            data3 = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM dinner");
            while (rs.next()) {
                //get string from db,whichever way 
                data3.add(new Dinner(rs.getString(1), rs.getString(2)));
            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        //Set cell value factory to tableview.
        //NB.PropertyValue Factory must be the same with the one set in model class.
        day3.setCellValueFactory(new PropertyValueFactory<>("day"));
        item3.setCellValueFactory(new PropertyValueFactory<>("items"));
        table3.setItems(null);
        table3.setItems(data3);
    }

    @FXML
    private void loadvalue1(ActionEvent event) {
        stackpane.setVisible(false);
    }

    @FXML
    private void loadvalue21(ActionEvent event) {
        stackpane2.setVisible(false);
    }

    @FXML
    private void loadvalue31(ActionEvent event) {
        stackpane3.setVisible(false);
    }

    @FXML
    private void close(ActionEvent event) {
         try {
                       
                        AnchorPane pane = FXMLLoader.load(getClass().getResource("StudentDashboard.fxml"));
                        anchorpane.getChildren().setAll(pane);

                       FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
                       fade1.setFromValue(0);
                       fade1.setToValue(1);
                       fade1.play();
                       } catch (IOException ex) {
                       Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
                       }
    }
    
}
