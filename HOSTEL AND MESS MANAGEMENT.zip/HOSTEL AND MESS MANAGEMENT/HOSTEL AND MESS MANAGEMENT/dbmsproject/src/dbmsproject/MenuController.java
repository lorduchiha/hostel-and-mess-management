/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class MenuController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorpane;
    PreparedStatement pst = null;
    @FXML
    private JFXButton b1;
    Connection conn = null;
    @FXML
    private Button btnBreak;
    @FXML
    private Button btnLunch;
    @FXML
    private Button btnDinner;

    @FXML
    void back(ActionEvent event) {
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("MessManagement.fxml"));
            anchorpane.getChildren().setAll(pane);

            FadeTransition fade1 = new FadeTransition(Duration.seconds(2), pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

//    private void loadDatafromExcel(ActionEvent event) throws IOException {
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel", "root", "open");
//            String query = "Insert into menu(Timings,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday) values(?,?,?,?,?,?,?,?)";
//            pst = conn.prepareStatement(query);
//          
//        } catch (ClassNotFoundException | SQLException e) {
//            JOptionPane.showMessageDialog(null, e);
//        }
//
//    }

    @FXML
    private void BreakFast(ActionEvent event) {
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("BreakFast.fxml"));
            anchorpane.getChildren().setAll(pane);

            FadeTransition fade1 = new FadeTransition(Duration.seconds(2), pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void Lunch(ActionEvent event) {
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("Lunch.fxml"));
            anchorpane.getChildren().setAll(pane);

            FadeTransition fade1 = new FadeTransition(Duration.seconds(2), pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void Dinner(ActionEvent event) {
        try {
            AnchorPane pane = FXMLLoader.load(getClass().getResource("Dinner.fxml"));
            anchorpane.getChildren().setAll(pane);

            FadeTransition fade1 = new FadeTransition(Duration.seconds(2), pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
        } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
