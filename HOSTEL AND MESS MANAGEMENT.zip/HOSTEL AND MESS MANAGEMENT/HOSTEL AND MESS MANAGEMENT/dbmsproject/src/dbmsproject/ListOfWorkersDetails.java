/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author niketan verma1
 */
public class ListOfWorkersDetails {
    //private final StringProperty sno;
    private final StringProperty name;
    private final StringProperty address;
    private final StringProperty contact;
    private final StringProperty date;
    private final StringProperty work;
    

    ListOfWorkersDetails( String name, String address, String contact, String date, String work) {
      
        this.name = new SimpleStringProperty(name);
        this.address = new SimpleStringProperty(address);
        this.contact = new SimpleStringProperty(contact);
        this.date = new SimpleStringProperty(date);
        this.work = new SimpleStringProperty(work);
      
    }
    
    public String getName() {
        return name.get();
    }
    public String getAddress() {
        return address.get();
    }
    public String getContact() {
        return contact.get();
    }
    public String getDate() {
        return date.get();
    }
    public String getWork() {
        return work.get();
    }
    

    public void setName(String value) {
        name.set(value);
    }
    public void setAddress(String value) {
        address.set(value);
    }
     public void setContact(String value) {
        contact.set(value);
    }
     public void setDate(String value) {
        date.set(value);
    }
     public void setWork(String value) {
        work.set(value);
    }
      

    public StringProperty nameProperty() {
        return name;
    }
     public StringProperty addressProperty() {
        return address;
    }
    
    public StringProperty contactProperty() {
        return contact;
    }
     public StringProperty dateProperty() {
        return date;
    }
      public StringProperty workProperty() {
        return work;
    }
    
}
