/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.mysql.jdbc.PreparedStatement;
import static dbmsproject.InformationController.str1;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class GenerateBillController implements Initializable {

    
    static String s;
    static String ss;
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private JFXButton b1;
    @FXML
    private TextField amount;
    @FXML
    private TextField amount2;
    private String value;
    public int temp,temp2;
    @FXML
    private TextField amount1;
    @FXML
    private TextField amount21;
    @FXML
    void close(ActionEvent event) {
        try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("StudentDashboard.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        Connection conn2=null;
        PreparedStatement pstmt2=null;
        ResultSet rs2=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn2=DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
            pstmt2=(PreparedStatement) conn2.prepareStatement("select name from signupstudent where username = ?");
            pstmt2.setString(1,s);
            rs2=pstmt2.executeQuery();
            if(rs2.next())
            {    
              ss = (rs2.getString("name"));
               
            }    
        }
        catch(Exception e) {
             System.out.println(e);
        }
        // TODO
        //System.out.println(s);
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
            pstmt=(PreparedStatement) conn.prepareStatement("select * from generatebill where name = ?");
            pstmt.setString(1,ss);
            rs=pstmt.executeQuery();
            if(rs.next())
            {    
               value = (rs.getString("bill"));
               temp = Integer.parseInt(value);
               temp2 = temp-5600;
               temp = temp - temp2;
               amount.setText(Integer.toString(temp2));
               amount2.setText(Integer.toString(temp));
               amount1.setText(ss);
               amount21.setText(ss);
            }    
        }
        catch(Exception e) {
             System.out.println(e);
        }
    }    
    
}
