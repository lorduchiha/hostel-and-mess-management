/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class RemovemembersController implements Initializable {

    @FXML
    private JFXButton rem;
    @FXML
    private JFXButton back;
    @FXML
    private AnchorPane anchorpane;
    @FXML
    private TextField text1;
    @FXML
    private TextField text2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void removeit(ActionEvent event) {
        String name = text1.getText();
        String roll_no = text2.getText();
       
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Statement x = null;
        text1.setText(null);
        text2.setText(null);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel", "root", "open");
            pstmt = (PreparedStatement) conn.prepareStatement("delete from memberinfo where name=? and roll_no = ? ");
            pstmt.setString(1, name);
            pstmt.setString(2, roll_no);
            
            int i = pstmt.executeUpdate();
            if (i > 0) {
                JOptionPane.showMessageDialog(null, "Member Removed");
            } else {
                JOptionPane.showMessageDialog(null, "Member not found Or Wrong information");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    @FXML
    private void home(ActionEvent event) {
         try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("MessManagement.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
}
