/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author MAC
 */
public class searchstudentDetail{

    private final StringProperty name;
    private final StringProperty roll_no;
    private final StringProperty username;
    private final StringProperty father_name;
    private final StringProperty mother_name;
    private final StringProperty dob;
    private final StringProperty address;
    private final StringProperty phone;
    private final StringProperty doj;

    //Default constructor
    public searchstudentDetail(String name, String roll_no, String username, String father_name, String mother_name, String dob,String address,String phone,String doj) {
        this.name = new SimpleStringProperty(name);
        this.roll_no = new SimpleStringProperty(roll_no);
        this.username = new SimpleStringProperty(username);
        this.father_name = new SimpleStringProperty(father_name);
        this.mother_name = new SimpleStringProperty(mother_name);
        this.dob = new SimpleStringProperty(dob);
        this.address = new SimpleStringProperty(address);
        this.phone = new SimpleStringProperty(phone);
        this.doj = new SimpleStringProperty(doj);

    }

    //Getters
    public String getname() {
        return name.get();
    }

    public String getroll_no() {
        return roll_no.get();
    }

    public String getusername() {
        return username.get();
    }

    public String getfather_name() {
        return father_name.get();
    }

    public String getmother_name() {
        return mother_name.get();
    }

    public String getdob() {
        return dob.get();
    }
    
     public String getaddress() {
        return address.get();
    }
      public String getphone() {
        return phone.get();
    }
       public String getdoj() {
        return doj.get();
    }

    //Setters
    public void setname(String value) {
        name.set(value);
    }

    public void setRoll_no(String value) {
        roll_no.set(value);
    }

    public void setusername(String value) {
        username.set(value);
    }

    public void setfather_name(String value) {
        father_name.set(value);
    }

    public void setmother_name(String value) {
        mother_name.set(value);
    }

    public void setdob(String value) {
      dob.set(value);
    }

    public void setaddress(String value) {
      address.set(value);
    }
    public void setphone(String value) {
      phone.set(value);
    }
    public void setdoj(String value) {
      doj.set(value);
    }
    //Property values
    public StringProperty name() {
        return name;
    }

    public StringProperty roll_noProperty() {
        return roll_no;
    }

    public StringProperty usernameProperty() {
        return username;
    }

    public StringProperty father_nameProperty() {
        return father_name;
    }

    public StringProperty mother_nameProperty() {
        return mother_name;
    }

    public StringProperty dobProperty() {
        return dob;
    }
      public StringProperty addressProperty() {
        return address;
    }  
      public StringProperty phoneProperty() {
        return phone;
    }
      public StringProperty dojProperty() {
        return doj;
    }
      
      
}
