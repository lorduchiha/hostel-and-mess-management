/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXProgressBar;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class WelcomeController implements Initializable {

  
    @FXML
    private AnchorPane root;

    @FXML
    private StackPane stackpane;

    @FXML
    private Text welcome;

    @FXML
    private JFXProgressBar progress;

  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        FadeTransition fade = new FadeTransition(Duration.seconds(1),welcome);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.setCycleCount(8);
        fade.setAutoReverse(true);
        fade.play();

        fade.setOnFinished((e)->{
             try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("option.fxml"));
             root.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
       
        });
        
      
      }
}
