/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author niketan verma1
 */
public class MembersDetails {
   
    private final StringProperty name;
    private final StringProperty rollno;
    private final StringProperty roomno;
    private final StringProperty address;
    private final StringProperty contact;
    private final StringProperty date;
    private final StringProperty type;
    


    MembersDetails( String name, String rollno, String roomno, String address, String contact,String date,String type) {
        
        this.name = new SimpleStringProperty(name);
        this.rollno = new SimpleStringProperty(rollno);
        this.roomno = new SimpleStringProperty(roomno);
        this.address = new SimpleStringProperty(address);
        this.contact = new SimpleStringProperty(contact);
        this.date = new SimpleStringProperty(date);
        this.type = new SimpleStringProperty(type);
      
    }

   
    

    public String getName() {
        return name.get();
    }

    public String getRollno() {
        return rollno.get();
    }
    public String getRoomno() {
        return roomno.get();
    }
    public String getAddress() {
        return address.get();
    }
    public String getContact() {
        return contact.get();
    }
    public String getDate() {
        return date.get();
    }
    public String getType() {
        return type.get();
    }
     //Setters
   

    public void setName(String value) {
        name.set(value);
    }

    public void setRollno(String value) {
        rollno.set(value);
    }
    
    public void setRoomno(String value) {
        roomno.set(value);
    }
     public void setAddress(String value) {
        address.set(value);
    }
     public void setContact(String value) {
        contact.set(value);
    }
     public void setDate(String value) {
        date.set(value);
    }
     public void setType(String value) {
        type.set(value);
    }
     

    public StringProperty nameProperty() {
        return name;
    }

    public StringProperty rollnoProperty() {
        return rollno;
    }
    
    public StringProperty roomnoProperty() {
        return roomno;
    }
     public StringProperty addressProperty() {
        return address;
    }
    
    public StringProperty contactProperty() {
        return contact;
    }
     public StringProperty dateProperty() {
        return date;
    }
      public StringProperty typeProperty() {
        return type;
    }
   
    
}
