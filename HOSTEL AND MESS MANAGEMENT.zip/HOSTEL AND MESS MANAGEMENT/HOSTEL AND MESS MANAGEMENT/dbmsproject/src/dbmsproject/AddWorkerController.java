/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import java.beans.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class AddWorkerController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorpane;
    @FXML
    private TextField text1;

    @FXML
    private TextField text2;

    @FXML
    private TextField text3;

    @FXML
    private TextField text4;
     @FXML
    private TextField text41;

    @FXML
    private JFXButton b1;

    @FXML
    private JFXButton b2;

    @FXML
    void add(ActionEvent event) {
    String NAME=text1.getText();
    String ADDRESS= text2.getText();
    String PHONE_NO= text3.getText();
    String DATE_OF_JOINING= text4.getText();
    String WORK=text41.getText();   
    Connection conn=null;
    PreparedStatement pstmt=null;
    ResultSet rs=null;
    Statement x=null;
    text1.setText(null);
    text2.setText(null);
    text3.setText(null);
    text4.setText(null);
    text41.setText(null);
    try{
        Class.forName("com.mysql.jdbc.Driver");
        conn=DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
        pstmt=(PreparedStatement) conn.prepareStatement("insert into worker_info values(?,?,?,?,?)");
        pstmt.setString(1,NAME);
        pstmt.setString(2,ADDRESS);
        pstmt.setString(3,PHONE_NO);
        pstmt.setString(4,DATE_OF_JOINING);
        pstmt.setString(5,WORK);
        int i= pstmt.executeUpdate();
        if(i>0)
            JOptionPane.showMessageDialog(null,"Data is saved");
        else
            JOptionPane.showMessageDialog(null,"Data is not saved");
    }   
    catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
    
    }
    }

    @FXML
    void back(ActionEvent event) {
         try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("adminDashboard.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
