/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author pride
 */
public class SigninController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private JFXButton exitb;

    @FXML
    private JFXTextField usernamefeild;

    @FXML
    private JFXPasswordField passwordfield;

    @FXML
    private ImageView image1;

    @FXML
    private Label label1;

    @FXML
    private JFXButton forgetpassbutton;

    @FXML
    private JFXButton loginbutton;
    
    @FXML
    private JFXButton admin;
    
    @FXML
    void exit(ActionEvent event) {
       try {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("option.fxml"));
             anchorpane.getChildren().setAll(pane);
             
            FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
            fade1.setFromValue(0);
            fade1.setToValue(1);
            fade1.play();
            } catch (IOException ex) {
            Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }


    @FXML
    void login(ActionEvent event) {
        String s=usernamefeild.getText();
        String p=passwordfield.getText();
        String tmp="Registered";
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql:///hostel","root","open");
            pstmt=(PreparedStatement) conn.prepareStatement("select * from signupstudent");
            rs=pstmt.executeQuery();
            int flag=0;
            while(rs.next()) {
                if(s.equals(rs.getString("username")) && p.equals(rs.getString("password")) && tmp.equals(rs.getString("status"))) {      
                    try {
                        flag = 1; 
                        StudentDashboardController.str = s;
                        InformationController.str1 = s;
                        AnchorPane pane = FXMLLoader.load(getClass().getResource("StudentDashboard.fxml"));
                        anchorpane.getChildren().setAll(pane);

                       FadeTransition fade1  = new FadeTransition(Duration.seconds(2),pane);
                       fade1.setFromValue(0);
                       fade1.setToValue(1);
                       fade1.play();
                       } catch (IOException ex) {
                       Logger.getLogger(WelcomeController.class.getName()).log(Level.SEVERE, null, ex);
                       }
                           }
            }
            if(flag==0) {
                JOptionPane.showMessageDialog(null, "Wrong Username or Password or Not Registered", "Login Failed", JOptionPane.ERROR_MESSAGE);                
                
            }
        }
        catch(Exception e) {
             System.out.println(e);
        }
   
            
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
