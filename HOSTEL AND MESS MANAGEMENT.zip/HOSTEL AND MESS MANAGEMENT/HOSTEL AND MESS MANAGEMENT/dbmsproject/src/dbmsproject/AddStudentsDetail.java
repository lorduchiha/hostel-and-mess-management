/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbmsproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author niketan verma1
 */
public class AddStudentsDetail {
    //private final StringProperty sno;
    private final StringProperty name;
    private final StringProperty username;
    private final StringProperty rollno;
    private final StringProperty status;
    private final StringProperty password;


     AddStudentsDetail( String name, String username, String rollno,String password, String status) {
      
        this.name = new SimpleStringProperty(name);
        this.username = new SimpleStringProperty(username);
        this.rollno = new SimpleStringProperty(rollno);
        this.status = new SimpleStringProperty(status);
        this.password = new SimpleStringProperty(password);
      
    }
    
    public String getName() {
        return name.get();
    }
    public String getusername() {
        return username.get();
    }
    public String getrollno() {
        return rollno.get();
    }
   
    public String getstatus() {
        return status.get();
    }
    public String getpassword() {
        return password.get();
    }

    public void setName(String value) {
        name.set(value);
    }
    public void setusername(String value) {
        username.set(value);
    }
     public void setrollno(String value) {
        rollno.set(value);
    }
    
     public void setstatus(String value) {
        status.set(value);
    }
      public void setpassword(String value) {
        password.set(value);
    }
      

    public StringProperty nameProperty() {
        return name;
    }
     public StringProperty usernameProperty() {
        return username;
    }
    
    public StringProperty rollnoProperty() {
        return rollno;
    }
    
      public StringProperty statusProperty() {
        return status;
    }
     public StringProperty passwordproperty() {
        return password;
    }
    
}
